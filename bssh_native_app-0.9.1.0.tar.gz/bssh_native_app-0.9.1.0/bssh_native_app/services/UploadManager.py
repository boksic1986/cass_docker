import simplejson
import os
import shutil

from bssh_native_app.types.outputs import MetadataProperty


class UploadManager:
    """
    Class responsible for moving output Files to the appropriate location for upload to BaseSpace Sequence Hub

    Attributes:
        appsession_id (str): The ID of the BaseSpace Sequence Hub AppSession
    """
    def __init__(self, appsession_id):
        """
        Constructor

        Arguments:
            appsession_id (str): The ID of the BaseSpace Sequence Hub AppSession

        Returns:
              UploadManager
        """
        self.appsession_id = appsession_id
        self.__cached_output_files = {}

    def upload_outputs(self, output_directory_path, href_appsession, output_builder):
        """
        Moves output Files to the appropriate location for upload to BaseSpace Sequence Hub

        Arguments:
            output_directory_path (str): The output directory path (usually "/data/outputs").
            href_appsession (str): The BaseSpace Sequence Hub API HREF of the AppSession
            output_builder (OutputBuilder): The OutputBuilder object containing all the output Files to be uploaded
        """
        for output_appresult in output_builder.output_appresults:
            self.__upload_appresults(output_directory_path, href_appsession, output_appresult)

    def __upload_appresults(self, output_directory_path, href_appsession, output_appresult):
        output_appresult_directory_path = os.path.join(output_directory_path, "appresults",
                                                       output_appresult.output_project.id, output_appresult.name)
        os.makedirs(output_appresult_directory_path)
        metadata_file_path = os.path.join(output_appresult_directory_path,"_metadata.json")
        self.__write_app_result_metadata(metadata_file_path, href_appsession, output_appresult)
        for output_file in output_appresult.output_files:
            self.__move_output_files(output_appresult_directory_path, output_file)

    def __move_output_files(self, output_directory, output_file):
        candidate_destination_file_path = os.path.join(os.path.abspath(output_directory), output_file.relative_destination_path)
        candidate_destination_directory_path = os.path.dirname(candidate_destination_file_path)
        candidate_file_name = os.path.basename(candidate_destination_file_path)
        destination_file_path = self.__get_unique_filename(candidate_destination_directory_path, candidate_file_name)
        destination_directory_path = os.path.dirname(destination_file_path)
        if not os.path.exists(destination_directory_path):
            os.makedirs(destination_directory_path)
        if output_file.source_file_path not in self.__cached_output_files:
            shutil.move(output_file.source_file_path, destination_file_path)
            self.__cached_output_files[output_file.source_file_path] = destination_file_path
        else:
            shutil.copy(self.__cached_output_files[output_file.source_file_path], destination_file_path)

    def __write_app_result_metadata(self, metadata_file_path, href_appsession, output_appresult):
        properties = list(output_appresult.properties)
        if len(output_appresult.input_samples) > 0:
            input_sample_hrefs = map(lambda s: s.href, output_appresult.input_samples)
            properties.append(MetadataProperty("sample[]", "Input.Samples", None, None, input_sample_hrefs))
        if len(output_appresult.input_appresults) > 0:
            input_appresult_hrefs = map(lambda s: s.href, output_appresult.input_appresults)
            properties.append(MetadataProperty("appresult[]", "Input.AppResults", None, None, input_appresult_hrefs))
        if len(output_appresult.input_files) > 0:
            input_file_hrefs = map(lambda s: s.href, output_appresult.input_files)
            properties.append(MetadataProperty("file[]", "Input.Files", None, None, input_file_hrefs))
        properties = self.__sanitize_properties(properties)
        with open(metadata_file_path, 'w') as metadata_file:
            appresult_metadata = {
                "Name": output_appresult.name,
                "Description": output_appresult.description,
                "HrefAppSession": href_appsession,
                "Properties": properties
            }
            simplejson.dump(appresult_metadata, metadata_file)

    def __sanitize_properties(self, raw_properties):
        properties = map(lambda m: m.__dict__, raw_properties)
        properties = map(lambda m: self.__remove_dictionary_none_values(m), properties)
        return properties

    def __remove_dictionary_none_values(self, dictionary):
        return dict((k, v) for k, v in dictionary.iteritems() if v is not None)

    def __get_unique_filename(self, directory_path, candidate_file_name):
        file_name_without_extension, file_extension = candidate_file_name.split(".", 1)
        candidate_file_path = os.path.join(directory_path, candidate_file_name)
        count = 0
        while os.path.exists(candidate_file_path):
            count += 1
            candidate_file_path = os.path.join(directory_path, file_name_without_extension + "_" + count+ file_extension)
        return candidate_file_path
