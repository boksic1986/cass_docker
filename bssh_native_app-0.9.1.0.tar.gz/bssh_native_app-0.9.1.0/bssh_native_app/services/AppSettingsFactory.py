import simplejson
import os
import re

from bssh_native_app.types.inputs import AppSettings, Property, ProjectResource, AppResultResource, FileResource, \
    RunResource, SampleResource, FastqSet


class AppSettingsFactory:
    """
    Class for parsing the AppSession.json file and using its data to generate an AppSettings object
    """
    def build_appsettings(self, input_directory_path):
        """
        Parses the AppSession.json file and uses its data to generate and return an AppSettings object

        Arguments:
            input_directory_path (str): The input directory path containing the AppSession.json file and other inputs
                (usually "/data/inputs").

        Returns:
             AppSettings: The AppSettings object containing all the properties found in the AppSession.json file
        """
        appsession_file_path = os.path.join(input_directory_path, "AppSession.json")
        with open(appsession_file_path) as appsession_file:
            appsession_json = simplejson.load(appsession_file)
        appsettings = AppSettings(appsession_json["Href"])
        for property_json_item in appsession_json["Properties"]["Items"]:
            content = self.__get_property_content(property_json_item, input_directory_path)
            appsetting_property = Property(property_json_item, content)
            appsettings.add_property(appsetting_property)
        return appsettings

    def __get_property_content(self, property_json, input_dir_path):
        items = self.__get_property_items(property_json)
        property_type = property_json["Type"].lower().replace("[]", "")
        if property_type == "appresult":
            return map(lambda item: self.__create_appresult_resource(item["Id"], input_dir_path), items)
        elif property_type == "file":
            return map(lambda item: self.__create_file_resource(item, input_dir_path), items)
        elif property_type == "map":
            return items
        elif property_type == "project":
            return map(lambda item: ProjectResource(item), items)
        elif property_type == "run":
            return map(lambda item: self.__create_run_resource(item["Id"], input_dir_path), items)
        elif property_type == "sample":
            return map(lambda item: self.__create_sample_resource(item["Id"], input_dir_path), items)
        elif property_type == "string":
            return items
        else:
            return None

    def __get_property_items(self, property_json):
        property_items = []
        if "Items" in property_json and property_json["Items"] is not None:
            property_items.extend(property_json["Items"])
        if "Content" in property_json and property_json["Content"] is not None:
            property_items.append(property_json["Content"])
        return property_items

    def __create_appresult_resource(self, appresult_id, input_dir_path):
        appresult_json_path = os.path.join(input_dir_path, "appresults", appresult_id + ".json")
        appresult_dir_path = os.path.join(input_dir_path, "appresults", appresult_id)
        with open(appresult_json_path) as appresult_json_file:
            appresult_json = simplejson.load(appresult_json_file)
        return AppResultResource(appresult_json, appresult_dir_path)

    def __create_file_resource(self, item, input_dir_path):
        parent_appresult_id = item["ParentAppResult"]["Id"]
        parent_appresult = self.__create_appresult_resource(parent_appresult_id, input_dir_path)
        return FileResource(item, parent_appresult)

    def __create_run_resource(self, run_id, input_dir_path):
        run_json_path = os.path.join(input_dir_path, "runs", run_id + ".json")
        run_dir_path = os.path.join(input_dir_path, "runs", run_id)
        with open(run_json_path) as run_json_file:
            run_json = simplejson.load(run_json_file)
        return RunResource(run_json, run_dir_path)

    def __create_sample_resource(self, sample_id, input_dir_path):
        sample_json_path = os.path.join(input_dir_path, "samples", sample_id + ".json")
        sample_dir_path = os.path.join(input_dir_path, "samples", sample_id)
        with open(sample_json_path) as sample_json_file:
            sample_json = simplejson.load(sample_json_file)
        fastq_sets = self.__create_fastq_sets(sample_dir_path)
        return SampleResource(sample_json, fastq_sets)

    def __create_fastq_sets(self, sample_dir_path):
        fastq_groups = {}
        fastq_regex = re.compile("(?P<samplename>^[a-zA-Z0-9_-]+)_S(?P<samplenumber>[^_]+)_L(?P<lane>[^_]+)_R(?P<read>[12])_(?P<flowcell>[0-9]+).fastq.gz$")
        for dirpath, dirnames, filenames in os.walk(sample_dir_path):
            for filename in [f for f in filenames if f.endswith(".fastq.gz")]:
                match = fastq_regex.match(filename)
                if bool(match):
                    sample_name = match.group("samplename")
                    sample_number = match.group("samplenumber")
                    lane = match.group("lane")
                    flowcell = match.group("flowcell")
                    read = match.group("read")
                    key = ".".join([dirpath, sample_name, sample_number, lane, flowcell])
                    if key not in fastq_groups:
                        fastq_groups[key] = FastqSet("", sample_name, sample_number, lane, flowcell)
                    if read == "1":
                        fastq_groups[key].read_1_file_path = os.path.join(dirpath, filename)
                    if read == "2":
                        fastq_groups[key].read_2_file_path = os.path.join(dirpath, filename)
        return fastq_groups.values()
