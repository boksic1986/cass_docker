import os

from bssh_native_app.types.outputs import OutputBuilder
from bssh_native_app.services.AppSettingsFactory import AppSettingsFactory
from bssh_native_app.services.UploadManager import UploadManager


class BaseSpaceNativeApp:
    """
    Base worker class for all BaseSpace Sequence Hub Native Apps. This class is intended to be inherited by a
    child class that implements the app-specific analysis workflow logic and steps by overriding the do_work
    class method
    """
    def __init__(self, input_directory_path, output_directory_path, scratch_directory_path, log_directory_path, appsession_id=None):
        """
        Constructor

        Attributes:
            input_directory_path (str): The local input directory path (usually "/data/inputs")
            output_directory_path (str): The local output directory path (usually "/data/outputs")
            scratch_directory_path (str): The local scratch directory path (usually "/data/scratch")
            log_directory_path (str): The local logging directory path (usually "/data/output/logs")
            appsession_id (str): The ID of the BaseSpace Sequence Hub AppSession

        Returns:
            BaseSpaceNativeApp
        """
        self.__input_directory_path = input_directory_path
        self.__output_directory_path = output_directory_path
        self.__scratch_directory_path = scratch_directory_path
        self.__log_directory_path = log_directory_path
        if appsession_id is None:
            self.__appsession_id = os.environ["AppSessionId"]
        else:
            self.__appsession_id = appsession_id

    def start(self):
        """
        Starts the Native App
        """
        appsettings_factory = AppSettingsFactory()
        appsettings = appsettings_factory.build_appsettings(self.__input_directory_path)
        output_builder = OutputBuilder()
        upload_manager = UploadManager(self.__appsession_id)
        self.do_work(self.__scratch_directory_path, appsettings, output_builder)
        upload_manager.upload_outputs(self.__output_directory_path, appsettings.href_appsession, output_builder)

    def do_work(self, workspace_directory, appsettings, output_builder):
        """
        Virtual class method intended to be overriden by a child class. The overriden method should implement all the
        app-specific analysis workflow logic and steps

        Arguments:
            workspace_directory (str): The local workspace directory to be used as scratch space. All temporary files
                created during data analysis and processing should be written to this directory
            appsettings (AppSettings): The AppSettings object containing all the properties found in the AppSession.json
                file
            output_builder: The OutputBuilder object to be used to create output AppResults and assign files to be
                uploaded to BaseSpace Sequence Hub
        """
        pass
