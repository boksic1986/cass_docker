import os


class JSONObject:
    """
    Class representing a JSON object
    """
    def __init__(self, json):
        """
        Constructor

        Args:
            json (object): The raw JSON dictionary that represents the object

        Returns:
            JSONObject
        """
        self._json = json

    def __getitem__(self, key):
        return self._json[key]


class Resource(JSONObject):
    """
    Class representing a BaseSpace Sequence Hub API Resource object
    """
    def __init__(self, json):
        """
        Constructor

        Args:
            json (object): The raw JSON dictionary that represents the Resource

        Returns:
            Resource
        """
        JSONObject.__init__(self, json)

    @property
    def id(self):
        """
        Returns:
            str: The ID of the Resource
        """
        return str(self["Id"])

    @property
    def name(self):
        """
        Returns:
            str: The name of the Resource
        """
        return str(self["Name"])

    @property
    def href(self):
        """
        Returns:
            str: The BaseSpace Sequence Hub API HREF of the Resource
        """
        return str(self["Href"])


class Property(JSONObject):
    """
    Class representing a BaseSpace Sequence Hub AppSession Property

    Attributes:
        content (list(object)): A list of objects (e.g. SampleResource, string, etc.) associated with this Property
    """
    def __init__(self, json, content):
        """
        Constructor

        Args:
            json (object): The raw JSON dictionary that represents the Property
            content (list(object)): A list of objects (e.g. SampleResource, string, etc.) associated with this Property

        Returns:
            Property
        """
        JSONObject.__init__(self, json)
        self.content = content

    @property
    def fullname(self):
        """
        Returns:
            str: The full name of the Property in the form of <Namespace>.<PropertyName>
        """
        return str(self["Name"])

    @property
    def namespace(self):
        """
        Returns:
            str: The namespace of the Property
        """
        return self.fullname.split(".", 1)[0]

    @property
    def name(self):
        """
        Returns:
            str: The name of the Property (without the namespace)
        """
        return self.fullname.split(".", 1)[1]

    @property
    def description(self):
        """
        Returns:
            str: The description of the Property
        """
        return str(self["Description"])

    @property
    def type(self):
        """
        Returns:
            str: The object type of the content contained within the Property (e.g. "Sample", "string", etc.)
        """
        return str(self["Type"])

    @property
    def href(self):
        """
        Returns:
            str: The BaseSpace Sequence Hub API HREF of the Property
        """
        return str(self["Href"])


class AppSettings:
    """
    Class for storing Properties parsed from AppSession.json file

    Attributes:
        properties (dict(str, dict(str, Property)): A nested dictionary of Property objects where the primary key is the
            namespace of a given Property and the secondary key is the name of the Property. For example, given a
            Property with a full name of "Input.Samples", it can be retrieved like this:
                sample_property = AppSettings.properties["Input"]["Samples"]
        href_appsession (str): The BaseSpace Sequence Hub API HREF of the AppSession
    """
    def __init__(self, href_appsession):
        """
        Constructor

        Args:
            href_appsession (str): The BaseSpace Sequence Hub API HREF of the AppSession

        Returns:
            AppSettings
        """
        self.properties = {"Input": {}, "Output": {}}
        self.href_appsession = href_appsession

    def __getitem__(self, namespace):
        return self.properties[namespace]

    @property
    def input(self):
        """
        Returns:
            dict(str, Property): A dictionary containing all the Property objects with "Input" as the namespace. The
                key of the dictionary is the name of a Property. For example, given a Property with a full name of
                "Input.Samples", it can be retrieved like this:
                    sample_property = AppSettings.input["Samples"]
        """
        return self.properties["Input"]

    @property
    def output(self):
        """
        Returns:
            dict(str, Property): A dictionary containing all the Property objects with "Output" as the namespace. The
                key of the dictionary is the name of a Property. For example, given a Property with a full name of
                "Output.project-id", it can be retrieved like this:
                    sample_property = AppSettings.output["project-id"]
        """
        return self.properties["Output"]

    def add_property(self, appsetting_property):
        """
        Adds a Property object to the AppSettings object

        Args:
            appsetting_property (Property): The Property object to be added to the AppSettings object
        """
        namespace = appsetting_property.namespace
        if namespace not in self.properties:
            self.properties[namespace] = {}
        self.properties[appsetting_property.namespace][appsetting_property.name] = appsetting_property


class AppResultResource(Resource):
    """
    Class representing an input BaseSpace Sequence Hub API AppResult resource object

    Attributes:
        directory_path (str): The local directory path where the AppResult is located
    """
    def __init__(self, json, appresult_directory_path):
        """
        Constructor

        Args:
            json (object): The raw JSON dictionary that represents the AppResult
            appresult_directory_path (str): The local directory path where the AppResult is located

        Returns:
            AppResultResource
        """
        Resource.__init__(self, json)
        self.directory_path = appresult_directory_path

    @property
    def description(self):
        """
        Returns:
             str: The description of the AppResult
        """
        return str(self["Description"])

    @property
    def total_size(self):
        """
        Returns:
            long: The total size of the AppResult files in bytes
        """
        return long(self["TotalSize"])


class FileResource(Resource):
    """
    Class representing an input BaseSpace Sequence Hub API File resource object

    Attributes:
        parent_appresult (AppResultResource): The parent AppResult the File belongs to
        file_path (str): The local file path where the File is located
    """
    def __init__(self, json, parent_appresult=None):
        """
        Constructor

        Args:
            json (object): The raw JSON dictionary that represents the File
            parent_appresult (Optional[AppResultResource]): The parent AppResult that the File belongs to

        Returns:
            AppResultResource
        """
        Resource.__init__(self, json)
        self.parent_appresult = parent_appresult
        if self.parent_appresult is not None:
            self.file_path = os.path.join(self.parent_appresult.directory_path, self["Path"])
        else:
            self.file_path = None

    @property
    def size(self):
        """
        Returns:
            long: The total size of the File in bytes
        """
        return long(self["Size"])


class ProjectResource(Resource):
    """
    Class representing an input BaseSpace Sequence Hub API Project resource object
    """
    def __init__(self, json):
        """
        Constructor

        Args:
            json (object): The raw JSON dictionary that represents the Project

        Returns:
            ProjectResource
        """
        Resource.__init__(self, json)


class RunResource(Resource):
    """
    Class representing an input BaseSpace Sequence Hub API Run resource object

    Attributes:
        directory_path (str): The local directory path where the input AppResult is located
        sequencing_statistics (SequencingStatistics): The set of sequencing statistics associated with the Run
    """
    def __init__(self, json, run_directory_path):
        """
        Constructor

        Args:
            json (object): The raw JSON dictionary that represents the Run
            run_directory_path (str): The local directory path where the Run is located

        Returns:
            RunResultResource
        """
        Resource.__init__(self, json)
        self.directory_path = run_directory_path
        self.sequencing_statistics = SequencingStatistics(json["SequencingStatistics"])

    @property
    def experiment_name(self):
        """
        Returns:
            str: The name of the experiment, set by the user who uploads the Run
        """
        return str(self["ExperimentName"])

    @property
    def reagent_barcode(self):
        """
        Returns:
            str: The barcode of the reagents used to sequence the Run
        """
        return str(self["ReagentBarcode"])

    @property
    def flowcell_barcode(self):
        """
        Returns:
            str: The barcode of the flowcell used to sequence the Run
        """
        return str(self["FlowcellBarcode"])

    @property
    def platform_name(self):
        """
        Returns:
            str: The name of the platform used to sequence the Run
        """
        return str(self["PlatformName"])

    @property
    def instrument_name(self):
        """
        Returns:
            str: The name of the instrument used to sequence the Run
        """
        return str(self["InstrumentName"])

    @property
    def instrument_type(self):
        """
        Returns:
            str: The type of instrument used to sequence the Run
        """
        return str(self["InstrumentType"])

    @property
    def total_size(self):
        """
        Returns:
            long: The total size of the Run in bytes
        """
        return long(self["TotalSize"])


class SequencingStatistics(JSONObject):
    """
    Class representing the metadata for the sequencing statistics of a Run
    """
    def __init__(self, json):
        """
        Constructor

        Args:
            json (object): The raw JSON dictionary that represents the sequencing statistics of the Run

        Returns:
            SequencingStatistics
        """
        JSONObject.__init__(self, json)

    @property
    def is_indexed(self):
        """
        Returns:
             bool: Designates whether or not the Run is indexed
        """
        return bool(self["IsIndexed"])

    @property
    def yield_total(self):
        """
        Returns:
            float: The number of bases sequenced
        """
        return float(self["YieldTotal"])

    @property
    def projected_total_yield(self):
        """
        Returns:
            float: The projected number of bases sequenced at the end of the Run
        """
        return float(self["ProjectedTotalYield"])

    @property
    def percent_aligned(self):
        """
        Returns:
            float: The percentage of clusters that aligned to PhiX for the Run
        """
        return float(self["PercentAligned"])

    @property
    def error_rate(self):
        """
        Returns:
             float: The calculated error rate, as determined by the PhiX alignment
        """
        return float(self["ErrorRate"])

    @property
    def intensity_cycle_1(self):
        """
        Returns:
            float: The average of the four intensities (one per channel or base type) measured at the first cycle
                averaged over filtered clusters
        """
        return float(self["IntensityCycle1"])

    @property
    def percent_greater_than_q30(self):
        """
        Returns:
            float: The percentage of bases with a quality score of 30 or higher
        """
        return float(self["PercentGtQ30"])

    @property
    def max_cycle_called(self):
        """
        Returns:
             int: The maximum number of cycles called in the Run
        """
        return int(self["MaxCycleCalled"])

    @property
    def chemistry(self):
        """
        Returns:
            str: The chemistry used in the Run
        """
        return str(self["Chemistry"])

    @property
    def num_lanes(self):
        """
        Returns:
            int: The number of lanes in the Run
        """
        return int(self["NumLanes"])

    @property
    def num_surfaces(self):
        """
        Returns:
            int: The number of surfaces in the Run
        """
        return int(self["NumSurfaces"])

    @property
    def num_swaths_per_lane(self):
        """
        Returns:
            int: The number of swaths per lane in the Run
        """
        return int(self["NumSwathsPerLane"])

    @property
    def num_tiles_per_swath(self):
        """
        Returns:
            int: The number of tiles per swath in the Run
        """
        return int(self["NumTilesPerSwath"])

    @property
    def num_reads(self):
        """
        Returns:
            long: The number of reads sequenced in the Run
        """
        return long(self["NumReads"])

    @property
    def num_cycles_read_1(self):
        """
        Returns:
            int: The number of cycles sequenced for non-index read 1
        """
        return int(self["NumCyclesRead1"])

    @property
    def num_cycles_read_2(self):
        """
        Returns:
            int: The number of cycles sequenced for non-index read 2
        """
        return int(self["NumCyclesRead2"])

    @property
    def num_cycles_index_1(self):
        """
        Returns:
            int: The number of cycles sequenced for index read 1
        """
        return int(self["NumCyclesIndex1"])

    @property
    def num_cycles_index_2(self):
        """
        Returns:
            int: The number of cycles sequenced for non-index read 2
        """
        return int(self["NumCyclesIndex2"])

    @property
    def percent_resynthesis(self):
        """
        Returns:
            float: The ratio of first cycle intensities for Read 1 to first cycle intensities for Read 2
        """
        return float(self["PercentResynthesis"])


class SampleResource(Resource):
    """
    Class representing an input BaseSpace Sequence Hub API Sample resource object

    Attributes:
        fastq_sets (list(FastqSet)): A list of fastq files associated with the sample
    """
    def __init__(self, json, fastq_sets):
        """
        Constructor

        Args:
            json (object): The raw JSON dictionary that represents the sequencing statistics of the input Run
            fastq_sets (list(FastqSet)):  A list of fastq files associated with the sample

        Returns:
             SampleResource
        """
        Resource.__init__(self, json)
        self.fastq_sets = fastq_sets

    @property
    def sample_id(self):
        """
        Returns:
            str: The Id of the Sample from the samplesheet, this is specified by the user at the flow cell level
        """
        return str(self["SampleId"])

    @property
    def is_paired_end(self):
        """
        Returns:
            bool: Designates whether or not the read is a paired end read
        """
        return bool(self["IsPairedEnd"])

    @property
    def is_merged(self):
        """
        Returns:
            bool: Designates whether or not the Sample is a merged Sample
        """
        return bool(self["IsMerged"])

    @property
    def read_1(self):
        """
        Returns:
            int: The length of the first Read in number of bases
        """
        return int(self["Read1"])

    @property
    def read_2(self):
        """
        Returns:
            int: The length of the second Read in number of bases
        """
        return int(self["Read2"])

    @property
    def total_reads_raw(self):
        """
        Returns:
            long: The number of Reads for the Sample
        """
        return long(self["TotalReadsRaw"])

    @property
    def total_reads_pf(self):
        """
        Returns:
            long: The number of Reads for the Sample that have passed filters
        """
        return long(self["TotalReadsPF"])

    @property
    def total_clusters_raw(self):
        """
        Returns:
            long: The number of Clusters for the Sample
        """
        return long(self["TotalClustersRaw"])

    @property
    def total_clusters_pf(self):
        """
        Returns:
            long: The number of Reads for the Sample that have passed filters
        """
        return long(self["TotalClustersPF"])

    @property
    def total_size(self):
        """
        Returns:
            long: The total size of the Sample in bytes
        """
        return long(self["TotalSize"])


class FastqSet:
    """
    Class for storing file locations of a singleton FASTQ file or a pair of FASTQ files

    Attributes:
        sample_name (str): The value of the SampleName field in the FASTQ file name
        sample_number (str): The value of the SampleNumber field in the FASTQ file name
        lane (str): The value of the Lane field in the FASTQ file name
        flowcell (str): The value of the Flowcell field in the FASTQ file name
        read_1_file_path (str): The local file path where the FASTQ for read 1 is located
        read_2_file_path (str): The local file path where the FASTQ for read 2 is located. For single-end Samples, this
            value is None.
    """
    def __init__(self, sample_name, sample_number, lane, flowcell, read_1_file_path=None, read_2_file_path=None):
        """
        Constructor

        Args:
            sample_name (str): The value of the SampleName field in the FASTQ file name
            sample_number (str): The value of the SampleNumber field in the FASTQ file name
            lane (str): The value of the Lane field in the FASTQ file name
            flowcell (str): The value of the Flowcell field in the FASTQ file name
            read_1_file_path (Optional[str]): The local file path where the FASTQ for read 1 is located
            read_2_file_path (Optional[str]): The local file path where the FASTQ for read 2 is located. For single-end Samples,
                this value is None.

        Returns:
             FastqSet
        """
        self.sample_name = sample_name
        self.sample_number = sample_number
        self.lane = lane
        self.flowcell = flowcell
        self.read_1_file_path = read_1_file_path
        self.read_2_file_path = read_2_file_path

    @property
    def is_paired(self):
        """
        Returns:
            Designates whether or not the FASTQ set is paired and contains a read 2 FASTQ file
        """
        if self.read_1_file_path is not None and self.read_2_file_path is not None:
            return True
        else:
            return False


