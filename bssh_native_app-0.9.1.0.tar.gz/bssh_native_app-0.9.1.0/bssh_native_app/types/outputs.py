import os


class MetadataProperty:
    """
    Class representing the output AppResult metadata properties to be written to the _metadata.json file

    Attributes:
        Type (str): The object type of the content contained within the output AppResult metadata property
            (e.g. "Sample", "string", etc.)
        Name (str): The name of the output AppResult metadata property
        Description (str): The description of the output AppResult metadata property
        Content (object): A single object associated with this output AppResult metadata property. For cases where
            multiple objects are associated, this value is None
        Items (list(object)): A list of objects (e.g. SampleResource, string, etc.) associated with this output
            AppResult metadata property. For cases where only a single object is associated, this value is None
    """
    def __init__(self, type, name, description, content=None, items=None):
        """
        Constructor

        Args:
            type (str): The object type of the content contained within the output AppResult metadata property
                (e.g. "Sample", "string", etc.)
            name (str): The name of the output AppResult metadata property
            description (str): The description of the output AppResult metadata property
            content (object): A single object associated with this output AppResult metadata property. For cases where
                multiple objects are associated, this value is None
            items (list(object)): A list of objects (e.g. SampleResource, string, etc.) associated with this output
                AppResult metadata property. For cases where only a single object is associated, this value is None

        Returns:
             MetadataProperty
        """
        self.Type = type
        self.Name = name
        self.Description = description
        self.Content = content
        self.Items = items


class OutputAppResult:
    """
    Class representing an output AppResult to be uploaded to BaseSpace Sequence Hub

    Attributes:
        name (str): The name of the output AppResult
        description (str): The description of the output AppResult
        output_project (ProjectResource): The BaseSpace Sequence Hub Project where the output AppResult will be uploaded
        properties (list(MetadataProperty)): A list of metadata properties associated with this output AppResult
        input_samples (list(SampleResource)): A list of input Samples associated with this output AppResult
        input_appresults (list(AppResultResource)): A list of input AppResults associated with this output AppResult
        input_files (list(FileResource)): A list of input Files associated with this output AppResult
        output_files (list(FileResource)): A list of output Files associated with this output AppResult that will be
            uploaded to BaseSpace Sequence Hub
    """
    def __init__(self, output_project_resource, name, description):
        """
        Constructor

        Arguments:
            output_project_resource (ProjectResource): The BaseSpace Sequence Hub Project where the output AppResult
                will be uploaded
            name (str): The name of the output AppResult
            description (str): The description of the output AppResult

        Returns:
             OutputAppResult
        """
        self.name = name
        self.description = description
        self.output_project = output_project_resource
        self.properties = []
        self.input_samples = []
        self.input_appresults = []
        self.input_files = []
        self.output_files = []

    def add_string_property(self, name, description, *values):
        """
        Adds a string metadata property to the output AppResult

        Arguments:
            name (str): The name of the metadata property
            description (str): The description of the metadata property
            *values (str): A variable length argument list of string values to be assigned to this metadata property
        """
        if len(values) == 1:
            self.properties.append(MetadataProperty("string", name, description, values[0]))
        elif len(values) > 1:
            self.properties.append(MetadataProperty("string[]", name, description, None, values))

    def add_input_sample_resources(self, *sample_resources):
        """
        Adds an input Sample metadata property to the output AppResult

        Arguments:
             *sample_resources (SampleResource): A variable length argument list of input Samples to be assigned to this
                metadata property
        """
        self.input_samples.extend(sample_resources)

    def add_input_appresult_resources(self, *appresult_resources):
        """
        Adds an input AppResult metadata property to the output AppResult

        Arguments:
            *appresult_resources (AppResultResource): A variable length argument list of input AppResults to be assigned
                to this metadata property
        """
        self.input_appresults.extend(appresult_resources)

    def add_input_file_resources(self, *file_resources):
        """
        Adds an input File metadata property to the output AppResult

        Arguments:
            *file_resources (FileResource): A variable length argument list of input Files to be assigned
                to this metadata property
        """
        self.input_files.extend(file_resources)

    def add_file(self, source_file_path, destination_file_name=None, *destination_relative_folder_paths):
        """
        Adds an output File to the output AppResult for upload to BaseSpace Sequence Hub.

        Arguments:
            source_file_path (str): The local file path where the output File is located
            destination_file_name (Optional[str]): The filename that the output File will be renamed to when it is
                uploaded to BaseSpace Sequence Hub. If this value is None, then the output File will not be renamed and
                will retain its original file name. For example, if the source_file_path is set to
                "/data/scratch/source.txt" and the destination_file_name is set to None, then the file will be uploaded
                with the filename "source.txt". But if the destination _file_name is set to "dest.txt", then the file
                will be uploaded with the filename "dest.txt"
            *destination_relative_folder_paths (str): A variable length argument list of strings to be used as output
                AppResult sub-folder names where the output File will be uploaded to. If this value is None or an empty
                list, then the output File will be uploaded to the top-level directory of the output AppResult. For
                example, if the source_file_path is set to "/data/scratch/source.txt" and
                *destination_relative_folder_paths is set to None, then the file will be uploaded to
                <AppResult>/source.txt. But if *destination_relative_folder_paths is set to ["one", "two", "three"],
                then the file will be uploaded to <AppResult>/one/two/three/source.txt.
        """
        src_file_path = os.path.abspath(source_file_path)
        relative_dest_path = ""
        if destination_relative_folder_paths is not None and len(destination_relative_folder_paths) > 0:
            relative_dest_path = os.path.join(*filter(None, destination_relative_folder_paths))
        if destination_file_name is not None and not destination_file_name.isspace() and not destination_file_name == "":
            relative_dest_path = os.path.join(relative_dest_path, destination_file_name)
        else:
            relative_dest_path = os.path.join(relative_dest_path, os.path.basename(src_file_path))
        self.output_files.append(OutputFile(src_file_path, relative_dest_path))

    def add_directory(self, source_directory_path, *destination_relative_folder_paths):
        """
        Adds an entire directory tree and its files to the output AppResult for upload to BaseSpace Sequence Hub.
        Output Files found within the directory tree will be uploaded to the AppResult in the same relative
        sub-directories as originally found.

        Arguments:
            source_directory_path (str): The local directory path where the directory to be uploaded is located
            *destination_relative_folder_paths (str): A variable length argument list of strings to be used as output
                AppResult sub-folder names where the directory will be uploaded to. If this value is None or an empty
                list, then the directory will be uploaded to the top-level directory of the output AppResult. For
                example, the following files will be uploaded to these locations:

                (given source_directory_path is "/data/scratch/Dir" and *destination_relative_folder_paths is None or
                an empty list )
                Source Local File Path                      Dest AppResult File Path
                -----------------                           ---------------
                /data/scratch/Dir/file1.txt             ->  <AppResult>/Dir/file1.txt
                /data/scratch/Dir/Dir2/file2.txt        ->  <AppResult>/Dir/Dir2/file2.txt
                /data/scratch/Dir/Dir2/Dir3/file3.txt   ->  <AppResult>/Dir/Dir2/Dir3/file3.txt

                (given source_directory_path is "/data/scratch/Dir" and *destination_relative_folder_paths is
                ["1", "2", "3"])
                Source Local File Path                      Dest AppResult File Path
                -----------------                           ---------------
                /data/scratch/Dir/file1.txt             ->  <AppResult>/1/2/3/Dir/file1.txt
                /data/scratch/Dir/Dir2/file2.txt        ->  <AppResult>/1/2/3/Dir/Dir2/file2.txt
                /data/scratch/Dir/Dir2/Dir3/file3.txt   ->  <AppResult>/1/2/3/Dir/Dir2/Dir3/file3.txt
        """
        src_dir_path = os.path.abspath(source_directory_path)
        if destination_relative_folder_paths is None or len(destination_relative_folder_paths) == 0:
            destination_relative_folder_paths = [os.path.basename(src_dir_path)]

        for dirpath, dirnames, filenames in os.walk(src_dir_path):
            sub_directory_relative_paths = list(destination_relative_folder_paths)
            extra_relative_paths = dirpath.replace(src_dir_path, "")
            sub_directory_relative_paths.extend(filter(None, extra_relative_paths.split(os.path.sep)))
            for file in filenames:
                self.add_file(os.path.join(dirpath, file), "", *sub_directory_relative_paths)


class OutputBuilder:
    """
    Class responsible for creating AppSession outputs, such as output AppResults and Files.

    Attributes:
        output_appresults (list(OutputAppResult)): A list of output AppResults that will be uploaded to BaseSpace
            Sequence Hub.
    """
    def __init__(self):
        """
        Constructor

        Returns:
            OutputBuilder
        """
        self.output_appresults = []
        self.__output_appresult_names = set()

    def create_output_appresult(self, output_project_resource, name, description):
        """
        Creates and returns an output AppResult that will be uploaded to BaseSpace Sequence Hub

        Arguments:
            output_project_resource (ProjectResource): The BaseSpace Sequence Hub Project where the AppResult will get
                uploaded
            name (str): The name of the output AppResult
            description (str): The description of the output AppResult

        Returns:
            OutputAppResult: An output AppResult. This object can be used to assign files that will get uploaded to the
                AppResult
        """
        appresult_name = name
        count = 0
        while appresult_name in self.__output_appresult_names:
            count += 1
            appresult_name = "%s (%s)" % (name, count)

        self.__output_appresult_names.add(appresult_name)
        output_appresult = OutputAppResult(output_project_resource, appresult_name, description)
        self.output_appresults.append(output_appresult)
        return output_appresult


class OutputFile:
    """
    Class representing an output File to be uploaded to an AppResult in BaseSpace Sequence Hub

    Attributes:
        source_file_path (str): The local file path where the output File is located
        relative_destination_path (str): The destination file path where the output File will be uploaded, relative
            to the AppResult. For example, if relative_destination_path is set to "/dir1/dir2/dir3/file.txt", then the
            file will be uploaded to <AppResult>/dir1/dir2/dir3/file.txt, regardless of what source_file_path is set to
    """
    def __init__(self, source_file_path, relative_destination_path=None):
        """
        Constructor

        Arguments:
            source_file_path (str): The local file path where the output File is located
            relative_destination_path (str): The destination file path where the output File will be uploaded, relative
            to the AppResult. For example, if relative_destination_path is set to "/dir1/dir2/dir3/file.txt", then the
            file will be uploaded to <AppResult>/dir1/dir2/dir3/file.txt, regardless of what source_file_path is set to

        Returns:
            OutputFile
        """
        src_file_path = os.path.abspath(source_file_path)
        self.source_file_path = src_file_path
        if relative_destination_path is None or relative_destination_path.isspace() or relative_destination_path == "":
            self.relative_destination_path = os.path.basename(src_file_path)
        else:
            self.relative_destination_path = relative_destination_path