from distutils.core import setup

setup(
    name='bssh_native_app',
    version='0.9.1.0',
    packages=['bssh_native_app', 'bssh_native_app.types', 'bssh_native_app.services'],
    author='ppcherng',
    author_email='ppcherng@gmail.com',
    description='Python library for writing BaseSpace Native Apps',
    requires=['simplejson']
)
